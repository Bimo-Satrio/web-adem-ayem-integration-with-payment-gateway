<?php
// config for Koossaayy/LaravelMapbox
return [
    'mapbox_token' => (env('MAPBOX_TOKEN'))
];
