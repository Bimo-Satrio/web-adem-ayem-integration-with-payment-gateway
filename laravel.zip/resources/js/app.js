import "./bootstrap";
import "jquery";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel";

import "bootstrap-select";
import "bootstrap-select/dist/css/bootstrap-select.min.css";
