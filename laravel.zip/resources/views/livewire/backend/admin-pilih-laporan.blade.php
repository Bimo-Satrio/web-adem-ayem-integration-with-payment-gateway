<div>

    <h5>Piih Jenis Laporan</h5>

    <div class="card">

        <div class="card-body">
            <h5>Laporan Pembayaran Pengajuan Sewa</h5>
            <a href="{{ route('admin-laporan-pembayaran-pengajuan') }}" class="stretched-link"></a>

        </div>
    </div>

    <div class="card">

        <div class="card-body">
            <h5>Laporan Pembayaran Tagihan Penghuni</h5>
            <a href="{{ route('admin-laporan-pembayaran-tagihan') }}" class="stretched-link"></a>

        </div>
    </div>



</div>
