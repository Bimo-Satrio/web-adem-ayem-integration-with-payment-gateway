<div class="d-inline">
 <span class=" badge rounded-pill bg-danger"> {{$count}}</span>
</div>
