<div class="container">



    <div class="card">
        <div class="card-body">

                <h4>Terima Kasih, Identitas Anda Akan Admin Segera Konfirmasi Silahkan Cek Riwayat Transaksi Penyewan Atau Notifikasi Anda Secara Berkala  </h4>
                <h4>Ingin Menghubungi  ? </h4>
                <h4>Gunakan Fitur Live Chat Dipojok Kanan Bawah Atau Jika Admin Sedang Offline Anda Dapat Kontak Whatsapp Dengan Nomor  {{$users->no_telefon }} </h4>

            <a href="{{route('riwayat-pengajuan')}}">
                <p class="text-center"> Riwayat Pengajuan Penyewan</p>
            </a>
            <a href="/">
                <p class="text-center"> Kembali ke Beranda</p>
            </a>

        </div>
    </div>


</div>
