<div>
    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
        <?php echo e($pengajuan_sewa); ?>

</div>


<?php /**PATH D:\laragon\www\pengembangan-kontrakan-adem-ayem\resources\views/livewire/user-notification.blade.php ENDPATH**/ ?>