<div class="d-inline">
 <span class=" badge rounded-pill bg-danger"> <?php echo e($count); ?></span>
</div>
<?php /**PATH D:\laragon\www\pengembangan-kontrakan-adem-ayem\resources\views/livewire/notif.blade.php ENDPATH**/ ?>